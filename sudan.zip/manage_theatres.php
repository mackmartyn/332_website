<html>
 <head>
  <title>Theatres</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

 </head>
 <body>

   <?php session_start(); ?>
   <?php  if (isset($_SESSION['update_errors'])) : ?>
     <div class="alert alert-danger">
     <?php echo $_SESSION['update_errors']; ?>
     <?php  unset($_SESSION['update_errors']); ?>
   </div>
   <?php endif ?>

<h2>Edit Theatre Complexes </h2>

      <?php
      include_once("connect.php");
      $conn = connect();
      $sql= "SELECT * FROM theatre_complex WHERE 1";
      $result = $conn->query($sql);
      $lmao = "";
      //theatre complex result
      if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
        echo "<form action=update_theatre_complex.php method=post><fieldset><legend>Edit Theatre Complex: '{$row['Name']}'</legend>";
          echo "<p>Name:  <input type=text name=name required='{$lmao}' id=name value='{$row['Name']}' /></p>
          <p>Street:  <input type=text name=street id=street required='{$lmao}' value='{$row['Street']}' /></p>
          <p>Street No:  <input type=text name=street_num required='{$lmao}'  value='{$row['Street_num']}' /></p>
          <p> City:  <input type=text name=city required='{$lmao}' value='{$row['City']}' /></p>
          <p>Province:  <input type=text name=province required='{$lmao}' value='{$row['Province']}' /></p>
          <p>Country:  <input type=text name=country required='{$lmao}' id=name value='{$row['Country']}' /></p>
          <p>Postal:  <input type=text name=postal required='{$lmao}' id=name value='{$row['Postal_Code']}' /></p>
          <p>Phone Number:  <input type=text required='{$lmao}' name=phone_num value='{$row['Phone_num']}' /></p>
          <p>Price:  <input type=number name=price value='{$row['Movie_price']}' /></p>
          <p><input type=submit name=Submit value=Update /></p></fieldset>
          </form> ";
              //actual theatre result
              // if ($theatre_result->num_rows > 0) {
              //   while($theatre_row = $theatre_result->fetch_assoc()) {
              //     echo "<div class=theatre>Theatre: " . $theatre_row['Theatre_id'] . ", Capacity: " . $theatre_row['Max_seats'] .", Screen Size: "  . $theatre_row['Screen_size'] . "</div><br>";
              //     //print_r($theatre_row);
              //     $theatre_id = $theatre_row['Theatre_id'];
              //     $sql = "SELECT * FROM showing WHERE Theatre_id=$theatre_id";
              //     $showing_result = $conn->query($sql);
              //   }
              // }



        }
      }




    ?>





 </body>
</html>
