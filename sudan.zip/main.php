<html>
 <head>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <title>PHP Test</title>
 </head>
 <body>
      <?php session_start(); ?>
      <?php  if (isset($_SESSION['email'])) : ?>
        <div class="jumbotron">
          <h1 class="display-4">Hello, <?php echo $_SESSION['email']; ?></h1>
          <p class="lead">Welcome to our Online Movie Ticket Database.</p>
          <hr class="my-4">
          <p>For theatres and showtimes, please click below.</p>
          <p class="lead">
            <a class="btn btn-info btn-dark" href="movies_index.php" role="button">Listings</a>
          </p>
        </div>

         <p> <a href="review_form.php"> Leave a Review </a></p>
         <p> <a href="edit_profile_form.php"> Edit My Profile </a> </p>
         <p> <a href="logout.php" >Logout</a> </p>
      <?php endif ?>
 </body>
</html>
