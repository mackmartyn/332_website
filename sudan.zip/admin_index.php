<html>
 <head>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <title>PHP Test</title>
 </head>
 <body>
      <?php session_start(); ?>
      <?php  if (isset($_SESSION['email'])) : ?>
        <div class="jumbotron">
          <h1 class="display-4">Hello, <?php echo $_SESSION['email']; ?></h1>
          <p class="lead">Welcome to your admin dashboard.</p>
          <hr class="my-4">
          <p>For theatres and showtimes, please click below.</p>
          <p class="lead">
            <a class="btn btn-info btn-dark" href="manage_members_view.php" role="button">Manage members</a>
          </p>
          <p class="lead">
            <a class="btn btn-info btn-dark" href="manage_theatres.php" role="button">Manage theatres</a>
          </p>
          <p class="lead">
            <a class="btn btn-info btn-dark" href="movies_index.php" role="button">Manage showings</a>
          </p>
          <p class="lead">
            <a class="btn btn-info btn-dark" href="movies_index.php" role="button">Add a Movie</a>
          </p>
          <p class="lead">
            <a class="btn btn-info btn-dark" href="movies_index.php" role="button">Analytics</a>
          </p>
        </div>


         <p> <a href="logout.php" >Logout</a> </p>
      <?php endif ?>
 </body>
</html>
